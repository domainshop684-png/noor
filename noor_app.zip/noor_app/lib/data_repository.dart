import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

import 'models.dart';

/// Loads every bundled JSON file once at start-up. Everything is offline.
class DataRepository {
  DataRepository._({
    required this.surahs,
    required this.azkar,
    required this.hadith,
    required this.duas,
  });

  final List<Surah> surahs;
  final List<DhikrCategory> azkar;
  final List<TextItem> hadith;
  final List<TextItem> duas;

  static Future<DataRepository> load() async {
    final quranRaw = await rootBundle.loadString('assets/data/quran.json');
    final azkarRaw = await rootBundle.loadString('assets/data/azkar.json');
    final hadithRaw = await rootBundle.loadString('assets/data/hadith.json');
    final duasRaw = await rootBundle.loadString('assets/data/duas.json');

    final surahs = (jsonDecode(quranRaw) as List)
        .map((e) => Surah.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);

    final azkarJson = jsonDecode(azkarRaw) as Map<String, dynamic>;
    final categories = (azkarJson['categories'] as List).map((c) {
      final cat = c as Map<String, dynamic>;
      final items = (cat['items'] as List).map((i) {
        final item = i as Map<String, dynamic>;
        final ref = item['ref'] as String?;
        final text = ref != null
            ? _quranText(surahs, ref)
            : (item['text'] as String? ?? '');
        return Dhikr(
          text: text,
          count: (item['count'] as int?) ?? 1,
          source: (item['source'] as String?) ?? '',
        );
      }).toList(growable: false);
      return DhikrCategory(
        id: cat['id'] as String,
        title: cat['title'] as String,
        items: items,
      );
    }).toList(growable: false);

    final hadith = ((jsonDecode(hadithRaw) as Map<String, dynamic>)['items']
            as List)
        .map((e) {
      final m = e as Map<String, dynamic>;
      return TextItem(
        text: m['text'] as String,
        subtitle: m['narrator'] as String?,
        source: m['source'] as String,
      );
    }).toList(growable: false);

    final duas =
        ((jsonDecode(duasRaw) as Map<String, dynamic>)['items'] as List).map((e) {
      final m = e as Map<String, dynamic>;
      return TextItem(
        title: m['title'] as String?,
        text: m['text'] as String,
        source: m['source'] as String,
      );
    }).toList(growable: false);

    return DataRepository._(
      surahs: surahs,
      azkar: categories,
      hadith: hadith,
      duas: duas,
    );
  }

  /// Resolves a reference such as "2:255" or "112:1-4" to Quran text.
  static String _quranText(List<Surah> surahs, String ref) {
    final parts = ref.split(':');
    final surah = surahs[int.parse(parts[0]) - 1];
    final range = parts[1].split('-');
    final from = int.parse(range[0]);
    final to = range.length > 1 ? int.parse(range[1]) : from;
    return surah.verses.sublist(from - 1, to).join(' ');
  }
}
