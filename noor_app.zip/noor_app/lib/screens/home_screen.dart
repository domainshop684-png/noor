import 'package:flutter/material.dart';

import '../app_state.dart';
import 'azkar_screen.dart';
import 'bookmarks_screen.dart';
import 'duas_screen.dart';
import 'hadith_screen.dart';
import 'quran_list_screen.dart';
import 'tasbeeh_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  static const _titles = ['القرآن الكريم', 'الأذكار', 'التسبيح', 'الأحاديث', 'الأدعية'];

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_index]),
        actions: [
          if (_index == 0)
            IconButton(
              tooltip: 'العلامات المحفوظة',
              icon: const Icon(Icons.bookmarks_outlined),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const BookmarksScreen()),
              ),
            ),
          IconButton(
            tooltip: 'الوضع الليلي',
            icon: Icon(state.dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
            onPressed: state.toggleDark,
          ),
        ],
      ),
      body: IndexedStack(
        index: _index,
        children: const [
          QuranListScreen(),
          AzkarScreen(),
          TasbeehScreen(),
          HadithScreen(),
          DuasScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'القرآن'),
          NavigationDestination(icon: Icon(Icons.wb_sunny_outlined), selectedIcon: Icon(Icons.wb_sunny), label: 'الأذكار'),
          NavigationDestination(icon: Icon(Icons.touch_app_outlined), selectedIcon: Icon(Icons.touch_app), label: 'التسبيح'),
          NavigationDestination(icon: Icon(Icons.format_quote_outlined), selectedIcon: Icon(Icons.format_quote), label: 'الأحاديث'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'الأدعية'),
        ],
      ),
    );
  }
}
