import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app_state.dart';
import '../models.dart';
import '../utils.dart';

/// List of azkar categories.
class AzkarScreen extends StatelessWidget {
  const AzkarScreen({super.key});

  static const _icons = <String, IconData>{
    'morning': Icons.wb_sunny_outlined,
    'evening': Icons.nights_stay_outlined,
    'after_prayer': Icons.mosque_outlined,
    'sleep': Icons.bedtime_outlined,
  };

  @override
  Widget build(BuildContext context) {
    final categories = AppScope.of(context).repo.azkar;
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: categories.length,
      itemBuilder: (context, i) {
        final c = categories[i];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: Icon(_icons[c.id] ?? Icons.auto_awesome, size: 32),
            title: Text(c.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            subtitle: Text('${toArabicDigits(c.items.length)} ذكر'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => AzkarCategoryScreen(category: c)),
            ),
          ),
        );
      },
    );
  }
}

/// One category: every dhikr has a tap-to-count button.
class AzkarCategoryScreen extends StatefulWidget {
  const AzkarCategoryScreen({super.key, required this.category});

  final DhikrCategory category;

  @override
  State<AzkarCategoryScreen> createState() => _AzkarCategoryScreenState();
}

class _AzkarCategoryScreenState extends State<AzkarCategoryScreen> {
  late List<int> _remaining;

  @override
  void initState() {
    super.initState();
    _reset();
  }

  void _reset() {
    _remaining = widget.category.items.map((d) => d.count).toList();
  }

  void _tap(int i) {
    if (_remaining[i] == 0) return;
    setState(() => _remaining[i]--);
    if (_remaining[i] == 0) {
      HapticFeedback.mediumImpact();
    } else {
      HapticFeedback.selectionClick();
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.category.items;
    final doneCount = _remaining.where((r) => r == 0).length;
    final scheme = Theme.of(context).colorScheme;
    final fontSize = AppScope.of(context).fontSize - 4;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.category.title),
        actions: [
          IconButton(
            tooltip: 'إعادة البدء',
            icon: const Icon(Icons.restart_alt),
            onPressed: () => setState(_reset),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(value: items.isEmpty ? 0 : doneCount / items.length),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.only(bottom: 24, top: 6),
        itemCount: items.length,
        itemBuilder: (context, i) {
          final d = items[i];
          final done = _remaining[i] == 0;
          return Opacity(
            opacity: done ? 0.5 : 1,
            child: Card(
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => _tap(i),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(d.text, style: TextStyle(fontSize: fontSize, height: 1.9)),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              d.source,
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: scheme.secondary),
                            ),
                          ),
                          IconButton(
                            tooltip: 'نسخ',
                            icon: const Icon(Icons.copy_rounded, size: 20),
                            onPressed: () => copyText(context, d.text),
                          ),
                          const SizedBox(width: 4),
                          CircleAvatar(
                            backgroundColor: done ? scheme.primary : scheme.primaryContainer,
                            foregroundColor: done ? scheme.onPrimary : scheme.onPrimaryContainer,
                            child: done
                                ? const Icon(Icons.check)
                                : Text(toArabicDigits(_remaining[i])),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
