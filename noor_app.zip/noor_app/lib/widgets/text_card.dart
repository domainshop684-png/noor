import 'package:flutter/material.dart';

import '../models.dart';
import '../utils.dart';

/// Card that shows a hadith or a dua with its source and a copy button.
class TextCard extends StatelessWidget {
  const TextCard({super.key, required this.item, this.fontSize = 20});

  final TextItem item;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (item.title != null) ...[
              Text(
                item.title!,
                style: theme.textTheme.titleSmall?.copyWith(
                  color: theme.colorScheme.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
            ],
            Text(item.text, style: TextStyle(fontSize: fontSize, height: 1.9)),
            const SizedBox(height: 10),
            if (item.subtitle != null)
              Text(
                item.subtitle!,
                style: theme.textTheme.bodySmall,
              ),
            Row(
              children: [
                Expanded(
                  child: Text(
                    item.source,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.secondary,
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'نسخ',
                  icon: const Icon(Icons.copy_rounded, size: 20),
                  onPressed: () => copyText(context, item.text),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
