import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app_state.dart';
import '../utils.dart';

class TasbeehScreen extends StatelessWidget {
  const TasbeehScreen({super.key});

  static const _labels = [
    'سبحان الله',
    'الحمد لله',
    'الله أكبر',
    'لا إله إلا الله',
    'أستغفر الله',
    'سبحان الله وبحمده',
    'اللهم صل وسلم على نبينا محمد',
  ];

  static const _targets = [33, 99, 100, 1000, 0];

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final scheme = Theme.of(context).colorScheme;
    final count = state.tasbeehCount;
    final target = state.tasbeehTarget;

    double progress = 0;
    if (target > 0 && count > 0) {
      progress = count % target == 0 ? 1.0 : (count % target) / target;
    }
    final rounds = target > 0 ? count ~/ target : 0;

    void onTap() {
      state.incrementTasbeeh();
      final next = state.tasbeehCount;
      if (target > 0 && next % target == 0) {
        HapticFeedback.heavyImpact();
      } else {
        HapticFeedback.selectionClick();
      }
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              for (final l in _labels)
                ChoiceChip(
                  label: Text(l),
                  selected: state.tasbeehLabel == l,
                  onSelected: (_) => state.setTasbeehLabel(l),
                ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            state.tasbeehLabel,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: onTap,
            child: SizedBox(
              width: 240,
              height: 240,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 240,
                    height: 240,
                    child: CircularProgressIndicator(
                      value: target > 0 ? progress : 0,
                      strokeWidth: 10,
                      backgroundColor: scheme.primaryContainer,
                    ),
                  ),
                  Container(
                    width: 200,
                    height: 200,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: scheme.primary,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      toArabicDigits(count),
                      style: TextStyle(
                        fontSize: 64,
                        color: scheme.onPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            target > 0
                ? 'الهدف: ${toArabicDigits(target)}  •  الدورات: ${toArabicDigits(rounds)}'
                : 'بدون هدف محدد',
          ),
          const SizedBox(height: 4),
          Text(
            'الإجمالي: ${toArabicDigits(state.tasbeehTotal)}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            alignment: WrapAlignment.center,
            children: [
              for (final t in _targets)
                ChoiceChip(
                  label: Text(t == 0 ? 'مفتوح' : toArabicDigits(t)),
                  selected: target == t,
                  onSelected: (_) => state.setTasbeehTarget(t),
                ),
            ],
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: state.resetTasbeeh,
            icon: const Icon(Icons.restart_alt),
            label: const Text('تصفير العداد'),
          ),
        ],
      ),
    );
  }
}
