import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'data_repository.dart';

/// App-wide state: settings, bookmarks, last-read position and tasbeeh counter.
/// Everything is persisted locally with shared_preferences.
class AppState extends ChangeNotifier {
  AppState(this._prefs, this.repo) {
    _dark = _prefs.getBool('dark') ?? false;
    _fontSize = _prefs.getDouble('fontSize') ?? 26;
    _bookmarks = (_prefs.getStringList('bookmarks') ?? <String>[]).toSet();
    _lastRead = _prefs.getString('lastRead');
    _tasbeehCount = _prefs.getInt('tasbeehCount') ?? 0;
    _tasbeehTarget = _prefs.getInt('tasbeehTarget') ?? 33;
    _tasbeehTotal = _prefs.getInt('tasbeehTotal') ?? 0;
    _tasbeehLabel = _prefs.getString('tasbeehLabel') ?? 'سبحان الله';
  }

  final SharedPreferences _prefs;
  final DataRepository repo;

  // ---- appearance ----
  late bool _dark;
  late double _fontSize;

  bool get dark => _dark;
  double get fontSize => _fontSize;

  void toggleDark() {
    _dark = !_dark;
    _prefs.setBool('dark', _dark);
    notifyListeners();
  }

  void changeFontSize(double delta) {
    _fontSize = (_fontSize + delta).clamp(18.0, 44.0).toDouble();
    _prefs.setDouble('fontSize', _fontSize);
    notifyListeners();
  }

  // ---- bookmarks & last read (keys look like "2:255") ----
  late Set<String> _bookmarks;
  String? _lastRead;

  Set<String> get bookmarks => _bookmarks;
  String? get lastRead => _lastRead;

  static String key(int surah, int ayah) => '$surah:$ayah';

  bool isBookmarked(int surah, int ayah) =>
      _bookmarks.contains(key(surah, ayah));

  void toggleBookmark(int surah, int ayah) {
    final k = key(surah, ayah);
    if (!_bookmarks.remove(k)) _bookmarks.add(k);
    _prefs.setStringList('bookmarks', _bookmarks.toList());
    notifyListeners();
  }

  void setLastRead(int surah, int ayah) {
    _lastRead = key(surah, ayah);
    _prefs.setString('lastRead', _lastRead!);
    notifyListeners();
  }

  // ---- tasbeeh ----
  late int _tasbeehCount;
  late int _tasbeehTarget;
  late int _tasbeehTotal;
  late String _tasbeehLabel;

  int get tasbeehCount => _tasbeehCount;
  int get tasbeehTarget => _tasbeehTarget; // 0 = unlimited
  int get tasbeehTotal => _tasbeehTotal;
  String get tasbeehLabel => _tasbeehLabel;

  void incrementTasbeeh() {
    _tasbeehCount++;
    _tasbeehTotal++;
    _prefs.setInt('tasbeehCount', _tasbeehCount);
    _prefs.setInt('tasbeehTotal', _tasbeehTotal);
    notifyListeners();
  }

  void resetTasbeeh() {
    _tasbeehCount = 0;
    _prefs.setInt('tasbeehCount', 0);
    notifyListeners();
  }

  void setTasbeehTarget(int target) {
    _tasbeehTarget = target;
    _prefs.setInt('tasbeehTarget', target);
    notifyListeners();
  }

  void setTasbeehLabel(String label) {
    _tasbeehLabel = label;
    _prefs.setString('tasbeehLabel', label);
    notifyListeners();
  }
}

/// Gives widgets access to [AppState] and rebuilds them when it changes.
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({
    super.key,
    required AppState state,
    required super.child,
  }) : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope not found in widget tree');
    return scope!.notifier!;
  }
}
