import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const _arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

/// 123 -> ١٢٣
String toArabicDigits(int n) =>
    n.toString().split('').map((c) => _arabicDigits[int.parse(c)]).join();

/// Removes diacritics and unifies letter shapes so search works naturally.
String normalizeArabic(String input) {
  var s = input;
  s = s.replaceAll(RegExp(r'[ؐ-ًؚ-ٰٟۖ-ۭـ]'), '');
  s = s.replaceAll(RegExp('[أإآٱ]'), 'ا');
  s = s.replaceAll('ى', 'ي').replaceAll('ة', 'ه');
  return s.trim().toLowerCase();
}

Future<void> copyText(BuildContext context, String text) async {
  await Clipboard.setData(ClipboardData(text: text));
  if (!context.mounted) return;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(const SnackBar(content: Text('تم النسخ'), duration: Duration(seconds: 1)));
}
