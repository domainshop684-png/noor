class Surah {
  const Surah({
    required this.id,
    required this.name,
    required this.transliteration,
    required this.type,
    required this.verses,
  });

  final int id;
  final String name;
  final String transliteration;

  /// "meccan" or "medinan"
  final String type;
  final List<String> verses;

  int get totalVerses => verses.length;
  String get typeAr => type == 'meccan' ? 'مكية' : 'مدنية';

  factory Surah.fromJson(Map<String, dynamic> json) {
    final verses = (json['verses'] as List)
        .map((v) => (v as Map<String, dynamic>)['text'] as String)
        .toList(growable: false);
    return Surah(
      id: json['id'] as int,
      name: json['name'] as String,
      transliteration: json['transliteration'] as String,
      type: json['type'] as String,
      verses: verses,
    );
  }
}

class Dhikr {
  const Dhikr({required this.text, required this.count, required this.source});

  final String text;
  final int count;
  final String source;
}

class DhikrCategory {
  const DhikrCategory({
    required this.id,
    required this.title,
    required this.items,
  });

  final String id;
  final String title;
  final List<Dhikr> items;
}

/// Generic text card used by hadith and dua lists.
class TextItem {
  const TextItem({
    required this.text,
    this.title,
    this.subtitle,
    required this.source,
  });

  final String text;
  final String? title;
  final String? subtitle;
  final String source;
}
