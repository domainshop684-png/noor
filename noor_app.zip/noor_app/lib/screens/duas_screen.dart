import 'package:flutter/material.dart';

import '../app_state.dart';
import '../widgets/text_card.dart';

class DuasScreen extends StatelessWidget {
  const DuasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = AppScope.of(context).repo.duas;
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: items.length,
      itemBuilder: (context, i) => TextCard(item: items[i], fontSize: 22),
    );
  }
}
