import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models.dart';
import '../utils.dart';
import 'surah_screen.dart';

class QuranListScreen extends StatefulWidget {
  const QuranListScreen({super.key});

  @override
  State<QuranListScreen> createState() => _QuranListScreenState();
}

class _QuranListScreenState extends State<QuranListScreen> {
  String _query = '';

  void _open(BuildContext context, Surah surah, [int ayah = 1]) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SurahScreen(surah: surah, initialAyah: ayah),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final all = state.repo.surahs;
    final q = normalizeArabic(_query);
    final surahs = q.isEmpty
        ? all
        : all.where((s) {
            return normalizeArabic(s.name).contains(q) ||
                s.transliteration.toLowerCase().contains(q) ||
                s.id.toString() == q;
          }).toList();

    final last = state.lastRead;
    final Surah? lastSurah =
        last == null ? null : all[int.parse(last.split(':')[0]) - 1];
    final int lastAyah = last == null ? 1 : int.parse(last.split(':')[1]);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: TextField(
            onChanged: (v) => setState(() => _query = v),
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: 'ابحث باسم السورة أو رقمها',
              border: OutlineInputBorder(),
              isDense: true,
            ),
          ),
        ),
        if (lastSurah != null && q.isEmpty)
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            color: Theme.of(context).colorScheme.primaryContainer,
            child: ListTile(
              leading: const Icon(Icons.bookmark_added_outlined),
              title: const Text('متابعة القراءة'),
              subtitle: Text('سورة ${lastSurah.name} — آية ${toArabicDigits(lastAyah)}'),
              onTap: () => _open(context, lastSurah, lastAyah),
            ),
          ),
        Expanded(
          child: ListView.builder(
            itemCount: surahs.length,
            itemBuilder: (context, i) {
              final s = surahs[i];
              return ListTile(
                leading: CircleAvatar(
                  child: Text(toArabicDigits(s.id), style: const TextStyle(fontSize: 14)),
                ),
                title: Text(
                  'سورة ${s.name}',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                ),
                subtitle: Text('${s.typeAr} • ${toArabicDigits(s.totalVerses)} آية'),
                trailing: Text(
                  s.transliteration,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                onTap: () => _open(context, s),
              );
            },
          ),
        ),
      ],
    );
  }
}
