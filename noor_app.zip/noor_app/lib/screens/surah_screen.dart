import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models.dart';
import '../utils.dart';

class SurahScreen extends StatefulWidget {
  const SurahScreen({super.key, required this.surah, this.initialAyah = 1});

  final Surah surah;
  final int initialAyah;

  @override
  State<SurahScreen> createState() => _SurahScreenState();
}

class _SurahScreenState extends State<SurahScreen> {
  final GlobalKey _targetKey = GlobalKey();

  static const _bismillah = 'بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ';

  @override
  void initState() {
    super.initState();
    if (widget.initialAyah > 1) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final ctx = _targetKey.currentContext;
        if (ctx != null) {
          Scrollable.ensureVisible(ctx, alignment: 0.1);
        }
      });
    }
  }

  void _showActions(BuildContext context, int ayah) {
    final state = AppScope.of(context);
    final surah = widget.surah;
    final text = surah.verses[ayah - 1];
    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text('سورة ${surah.name} — آية ${toArabicDigits(ayah)}'),
            ),
            ListTile(
              leading: Icon(
                state.isBookmarked(surah.id, ayah) ? Icons.bookmark_remove : Icons.bookmark_add_outlined,
              ),
              title: Text(state.isBookmarked(surah.id, ayah) ? 'إزالة العلامة' : 'حفظ علامة'),
              onTap: () {
                state.toggleBookmark(surah.id, ayah);
                Navigator.pop(sheetContext);
              },
            ),
            ListTile(
              leading: const Icon(Icons.flag_outlined),
              title: const Text('متابعة القراءة من هنا'),
              onTap: () {
                state.setLastRead(surah.id, ayah);
                Navigator.pop(sheetContext);
              },
            ),
            ListTile(
              leading: const Icon(Icons.copy_rounded),
              title: const Text('نسخ الآية'),
              onTap: () {
                Navigator.pop(sheetContext);
                copyText(context, '$text ﴿${toArabicDigits(ayah)}﴾ [${surah.name}]');
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final surah = widget.surah;
    final scheme = Theme.of(context).colorScheme;
    final lastRead = state.lastRead;

    return Scaffold(
      appBar: AppBar(
        title: Text('سورة ${surah.name}'),
        actions: [
          IconButton(
            tooltip: 'تصغير الخط',
            icon: const Icon(Icons.text_decrease),
            onPressed: () => state.changeFontSize(-2),
          ),
          IconButton(
            tooltip: 'تكبير الخط',
            icon: const Icon(Icons.text_increase),
            onPressed: () => state.changeFontSize(2),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 32),
        child: Column(
          children: [
            if (surah.id != 1 && surah.id != 9)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  _bismillah,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: state.fontSize + 2,
                    color: scheme.primary,
                    height: 1.8,
                  ),
                ),
              ),
            for (var i = 0; i < surah.verses.length; i++)
              _VerseTile(
                key: i + 1 == widget.initialAyah ? _targetKey : null,
                text: surah.verses[i],
                number: i + 1,
                fontSize: state.fontSize,
                bookmarked: state.isBookmarked(surah.id, i + 1),
                isLastRead: lastRead == AppState.key(surah.id, i + 1),
                onTap: () => state.setLastRead(surah.id, i + 1),
                onLongPress: () => _showActions(context, i + 1),
              ),
          ],
        ),
      ),
    );
  }
}

class _VerseTile extends StatelessWidget {
  const _VerseTile({
    super.key,
    required this.text,
    required this.number,
    required this.fontSize,
    required this.bookmarked,
    required this.isLastRead,
    required this.onTap,
    required this.onLongPress,
  });

  final String text;
  final int number;
  final double fontSize;
  final bool bookmarked;
  final bool isLastRead;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: isLastRead ? scheme.primaryContainer : null,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text.rich(
          TextSpan(
            children: [
              TextSpan(text: text),
              TextSpan(
                text: ' ﴿${toArabicDigits(number)}﴾ ',
                style: TextStyle(color: scheme.primary, fontSize: fontSize * 0.8),
              ),
              if (bookmarked)
                WidgetSpan(
                  alignment: PlaceholderAlignment.middle,
                  child: Icon(Icons.bookmark, size: fontSize * 0.7, color: scheme.tertiary),
                ),
            ],
          ),
          textAlign: TextAlign.justify,
          style: TextStyle(fontSize: fontSize, height: 2.0),
        ),
      ),
    );
  }
}
