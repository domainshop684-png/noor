import 'package:flutter/material.dart';

import '../app_state.dart';
import '../utils.dart';
import 'surah_screen.dart';

class BookmarksScreen extends StatelessWidget {
  const BookmarksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final entries = state.bookmarks.map((k) {
      final p = k.split(':');
      return (surah: int.parse(p[0]), ayah: int.parse(p[1]));
    }).toList()
      ..sort((a, b) => a.surah != b.surah ? a.surah.compareTo(b.surah) : a.ayah.compareTo(b.ayah));

    return Scaffold(
      appBar: AppBar(title: const Text('العلامات المحفوظة')),
      body: entries.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'لا توجد علامات بعد.\nاضغط مطولاً على أي آية لحفظ علامة.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.separated(
              itemCount: entries.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final e = entries[i];
                final surah = state.repo.surahs[e.surah - 1];
                final verse = surah.verses[e.ayah - 1];
                return ListTile(
                  title: Text(
                    verse,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 18, height: 1.8),
                  ),
                  subtitle: Text('سورة ${surah.name} — آية ${toArabicDigits(e.ayah)}'),
                  trailing: IconButton(
                    tooltip: 'حذف',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => state.toggleBookmark(e.surah, e.ayah),
                  ),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => SurahScreen(surah: surah, initialAyah: e.ayah),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
